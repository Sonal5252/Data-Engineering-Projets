# Databricks notebook source
# MAGIC %md
# MAGIC ### intitilating 
# MAGIC spark
# MAGIC

# COMMAND ----------

# MAGIC %md 
# MAGIC ## congiguration from databrics to azure storage account

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.oliststorageaccount2.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.oliststorageaccount2.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.oliststorageaccount2.dfs.core.windows.net", "4c286459-0776-44a0-b169-d191b6f7d9f9")
spark.conf.set("fs.azure.account.oauth2.client.secret.oliststorageaccount2.dfs.core.windows.net", "cCi8Q~zrU6Rn~acnYQL0h_nMo9N23RHj7gj.TcOE")
spark.conf.set("fs.azure.account.oauth2.client.endpoint.oliststorageaccount2.dfs.core.windows.net", "https://login.microsoftonline.com/7deca19a-c0e2-47ef-a790-5c27b8f06676/oauth2/token")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading data from bronze layer and creating a dataframe

# COMMAND ----------

df_customer = spark.read.option("header", "true")\
    .option("inferSchema", "true")\
    .csv("abfss://olistdata@oliststorageaccount2.dfs.core.windows.net/bronze/olist_customers_dataset.csv")  # Verify the file path and ensure the file exists at this location.
df_geolocation = spark.read.option("header", "true")\
    .option("inferSchema", "true")\
    .csv("abfss://olistdata@oliststorageaccount2.dfs.core.windows.net/bronze/olist_geolocation_dataset.csv")
df_order_items = spark.read.option("header", "true")\
    .option("inferSchema", "true")\
    .csv("abfss://olistdata@oliststorageaccount2.dfs.core.windows.net/bronze/olist_order_items_dataset.csv")
df_order_payments = spark.read.option("header", "true")\
    .option("inferSchema", "true")\
    .csv("abfss://olistdata@oliststorageaccount2.dfs.core.windows.net/bronze/olist_order_payments_dataset.csv")
df_order_reviews = spark.read.option("header", "true")\
    .option("inferSchema", "true")\
    .csv("abfss://olistdata@oliststorageaccount2.dfs.core.windows.net/bronze/olist_order_reviews_dataset.csv")
df_orders = spark.read.option("header", "true")\
    .option("inferSchema", "true")\
    .csv("abfss://olistdata@oliststorageaccount2.dfs.core.windows.net/bronze/olist_orders_dataset.csv")
df_products = spark.read.option("header", "true")\
    .option("inferSchema", "true")\
    .csv("abfss://olistdata@oliststorageaccount2.dfs.core.windows.net/bronze/olist_products_dataset.csv")
df_sellers = spark.read.option("header", "true")\
    .option("inferSchema", "true")\
    .csv("abfss://olistdata@oliststorageaccount2.dfs.core.windows.net/bronze/olist_sellers_dataset.csv")
df_product_category = spark.read.option("header", "true")\
    .option("inferSchema", "true")\
    .csv("abfss://olistdata@oliststorageaccount2.dfs.core.windows.net/bronze/product_category_name_translation.csv")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Conccting to mogodb

# COMMAND ----------

from pymongo import MongoClient

# COMMAND ----------

# importing module
from pymongo import MongoClient

hostname = "04u52t.h.filess.io"
database = "OlistDataNoSql_sheetform"
port = "61003"
username = "OlistDataNoSql_sheetform"
password = "3c7e41de1dbe1ff9daa9f2e9daf33f24c84b7676"

uri = "mongodb://" + username + ":" + password + "@" + hostname + ":" + port + "/" + database

# Connect with the portnumber and host
client = MongoClient(uri)

# Access database
mydatabase = client[database]


# COMMAND ----------

import pandas as pd
collection = mydatabase["product_categories"]

mongo_data = pd.DataFrame(list(collection.find()))


# COMMAND ----------

mongo_data

# COMMAND ----------

df_products.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### cleaning the data

# COMMAND ----------

from pyspark.sql.functions import col, lit, date_diff, to_date, to_timestamp, current_date

# COMMAND ----------

def clean_dataFrame(df, name):
    print("Cleaning DataFrame", name)
    return df.dropDuplicates().dropna('all')

# COMMAND ----------

df_customer = clean_dataFrame(df_customer, "df_customer")
df_geolocation = clean_dataFrame(df_geolocation, "df_geolocation")

display(df_customer)
display(df_geolocation)


# COMMAND ----------

df_order_items = clean_dataFrame(df_order_items, "df_order_items")
df_order_payments = clean_dataFrame(df_order_payments, "df_order_payments")
df_order_reviews = clean_dataFrame(df_order_reviews, "df_order_reviews")
df_orders = clean_dataFrame(df_orders, "df_orders")
df_products = clean_dataFrame(df_products, "df_products")
df_sellers = clean_dataFrame(df_sellers, "df_sellers")
df_product_category = clean_dataFrame(df_product_category, "df_product_category")

display(df_order_items)
display(df_order_payments)
display(df_order_reviews)
display(df_orders)
display(df_products)
display(df_sellers)


# COMMAND ----------

df_orders.display()

# COMMAND ----------

df_orders = df_orders.withColumn("order_purchase_timestamp", to_date('order_purchase_timestamp',))\
                    .withColumn("order_delivered_carrier_date", to_date('order_delivered_carrier_date',))\
                    .withColumn("order_estimated_delivery_date", to_date('order_estimated_delivery_date',))

# COMMAND ----------

df_orders = df_orders.withColumn('actual_delivery_time', date_diff(col('order_estimated_delivery_date'), col('order_purchase_timestamp')))
df_orders = df_orders.withColumn('estimated_delivery_time', date_diff(col('order_estimated_delivery_date'), col('order_purchase_timestamp')))
df_orders = df_orders.withColumn('Delay time', (col('actual_delivery_time')  - col('estimated_delivery_time')))
df_orders.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### JOINING

# COMMAND ----------

from pyspark.sql.functions import col

orders_customers_df = df_orders.join(
    df_customer,
    df_orders.customer_id == df_customer.customer_id,
    "left"
)



# COMMAND ----------

orders_payments_df = orders_customers_df.join(
    df_order_payments,
    orders_customers_df.order_id == df_order_payments.order_id,
    "left"
)



# COMMAND ----------

orders_items_df = orders_payments_df.join(
    df_order_items, "order_id", "left"
)




# COMMAND ----------

orders_items_products_df = orders_items_df.join(
    df_products,
    orders_items_df.product_id == df_products.product_id,
    "left"
)



# COMMAND ----------

final_df = orders_items_products_df.join(
    df_sellers,
    orders_items_products_df.seller_id == df_sellers.seller_id,
    "left"
)

# COMMAND ----------

display(final_df)

# COMMAND ----------

mongo_data.drop("_id",axis=1,inplace=True)
mongo_data_df = spark.createDataFrame(mongo_data)
display(mongo_data_df)

# COMMAND ----------

final_df = final_df.join(
    mongo_data_df, "product_category_name", "left"
)
display(final_df)


# COMMAND ----------

# MAGIC %md
# MAGIC #### move to silverlayer

# COMMAND ----------

final_df.columns

# COMMAND ----------

def remove_duplicate_columns(df):
    columns = df.columns

    seen_columns = set()
    columns_to_drop = []

    for column in columns:
        if column in seen_columns:
            columns_to_drop.append(column)
        else:
            seen_columns.add(column)

    df_cleaned = df.drop(*columns_to_drop)
    return df_cleaned

final_df = remove_duplicate_columns(final_df)


# COMMAND ----------

final_df.write.mode("overwrite").format("PARQUET").save("abfss://olistdata@oliststorageaccount2.dfs.core.windows.net/silver/")